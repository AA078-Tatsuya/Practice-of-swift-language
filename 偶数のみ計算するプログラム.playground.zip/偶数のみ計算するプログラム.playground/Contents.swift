for n in 1...9 {
    if n % 2 == 0 {
        for x in 1...9 {
            print(n * x)
        }
    }
}
