var sum = 0
for n in 1...100 {
    sum = sum + n
}
print(sum)
